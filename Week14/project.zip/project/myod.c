#include <stdio.h>
#include <stdlib.h>

void print_octal(const unsigned char *buffer, size_t length, size_t offset) {
    printf("%07o  ", (unsigned int)offset);
    for (size_t i = 0; i < length; i += 2) {
        if (i + 1 < length) {
            printf("%06o ", (buffer[i] << 8) | buffer[i + 1]);
        } else {
            printf("%06o ", buffer[i] << 8);
        }
    }
    printf("\n");
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "rb");
    if (!file) {
        perror("Error opening file");
        return 1;
    }

    unsigned char buffer[16];
    size_t bytesRead;
    size_t offset = 0;

    while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        print_octal(buffer, bytesRead, offset);
        offset += bytesRead;
    }

    fclose(file);
    return 0;
}

