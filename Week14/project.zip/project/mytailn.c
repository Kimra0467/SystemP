#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 256

int main(int argc, char *argv[]) {
    int num_lines = 10;  // 기본 줄 수

    // 명령줄 인수 처리
    char *filename;
    if (argc == 2) {
        filename = argv[1];
    } else if (argc == 4 && strcmp(argv[1], "-n") == 0) {
        num_lines = atoi(argv[2]);
        filename = argv[3];
    } else {
        fprintf(stderr, "Usage: %s [-n num_lines] <filename>\n", argv[0]);
        return 1;
    }

    // 파일 열기
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return 1;
    }

    // 줄 저장을 위한 순환 버퍼 초기화
    char **lines = malloc(num_lines * sizeof(char *));
    for (int i = 0; i < num_lines; i++) {
        lines[i] = NULL;
    }

    // 파일 읽기 및 순환 버퍼에 저장
    char buffer[MAX_LINE_LENGTH];
    int count = 0;
    while (fgets(buffer, sizeof(buffer), file)) {
        free(lines[count % num_lines]);
        lines[count % num_lines] = strdup(buffer);
        count++;
    }

    fclose(file);

    // 마지막 N줄 출력
    int start = count >= num_lines ? count % num_lines : 0;
    int lines_to_print = count < num_lines ? count : num_lines;

    for (int i = 0; i < lines_to_print; i++) {
        printf("%s", lines[(start + i) % num_lines]);
        free(lines[(start + i) % num_lines]);
    }

    free(lines);
    return 0;
}

