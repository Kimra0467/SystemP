#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "사용법: %s <디렉토리>\n", argv[0]);
        return 1;
    }

    // 지정된 디렉토리를 삭제합니다.
    if (rmdir(argv[1]) != 0) {
        perror("rmdir");
        return 1;
    }

    printf("디렉토리 '%s'가 성공적으로 삭제되었습니다.\n", argv[1]);
    return 0;
}

