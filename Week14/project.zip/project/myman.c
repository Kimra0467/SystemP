#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <command>\n", argv[0]);
        return 1;
    }

    // man 명령어를 호출하여 지정된 명령어의 매뉴얼 페이지를 표시
    char command[256];
    snprintf(command, sizeof(command), "man %s", argv[1]);
    int result = system(command);

    if (result == -1) {
        perror("system");
        return 1;
    }

    return 0;
}

