#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
        return 1;
    }

    char resolved_path[PATH_MAX];
    if (realpath(argv[1], resolved_path) == NULL) {
        perror("realpath");
        return 1;
    }

    printf("%s\n", resolved_path);
    return 0;
}

