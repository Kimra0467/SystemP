#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fp;
    char path[1035];

    // 'ps -eo pid,tty,time,cmd' 명령어를 실행하여 출력 결과를 읽어옵니다.
    fp = popen("ps -eo pid,tty,time,cmd", "r");
    if (fp == NULL) {
        perror("popen");
        exit(1);
    }

    // 명령어의 출력 결과를 한 줄씩 읽어와서 출력합니다.
    while (fgets(path, sizeof(path) - 1, fp) != NULL) {
        printf("%s", path);
    }

    // 파이프를 닫습니다.
    pclose(fp);

    return 0;
}

