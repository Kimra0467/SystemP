#include <stdlib.h>

int main() {
    // Use system call to execute the clear command
    system("clear");

    return 0;
}

