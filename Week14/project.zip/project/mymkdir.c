#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <directory_name>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *dir_name = argv[1];
    mode_t mode = 0755;  // 기본 디렉토리 권한

    if (mkdir(dir_name, mode) == -1) {
        perror("mkdir");
        exit(EXIT_FAILURE);
    }

    printf("Directory '%s' created successfully\n", dir_name);
    return 0;
}

