#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
        return 1;
    }

    char buffer[PATH_MAX];
    ssize_t len = readlink(argv[1], buffer, sizeof(buffer) - 1);
    if (len == -1) {
        perror("readlink");
        return 1;
    }

    buffer[len] = '\0';  // Null-terminate the string
    printf("%s\n", buffer);
    return 0;
}

