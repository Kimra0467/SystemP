#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

int main(int argc, char *argv[]) {
    DIR *d;
    struct dirent *dir;
    char *directory;

    // 디렉토리 경로를 인수로 받습니다. 인수가 없으면 현재 디렉토리를 사용합니다.
    if (argc > 1) {
        directory = argv[1];
    } else {
        directory = ".";
    }

    // 디렉토리를 엽니다.
    d = opendir(directory);
    if (d == NULL) {
        perror("opendir");
        return EXIT_FAILURE;
    }

    // 디렉토리의 내용을 읽어 출력합니다.
    while ((dir = readdir(d)) != NULL) {
        printf("%s\n", dir->d_name);
    }

    // 디렉토리를 닫습니다.
    closedir(d);
    return EXIT_SUCCESS;
}

