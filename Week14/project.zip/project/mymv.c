#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <source> <destination>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *source = argv[1];
    const char *destination = argv[2];

    // rename 함수를 사용하여 파일이나 디렉토리 이동 및 이름 변경
    if (rename(source, destination) == 0) {
        printf("'%s' has been moved/renamed to '%s'\n", source, destination);
    } else {
        perror("rename");
        exit(EXIT_FAILURE);
    }

    return 0;
}

