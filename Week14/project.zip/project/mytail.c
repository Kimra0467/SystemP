#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DEFAULT_NUM_LINES 10
#define MAX_LINE_LENGTH 256

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        perror("Error opening file");
        return 1;
    }

    char buffer[DEFAULT_NUM_LINES][MAX_LINE_LENGTH];
    int count = 0;

    while (fgets(buffer[count % DEFAULT_NUM_LINES], MAX_LINE_LENGTH, file)) {
        count++;
    }

    fclose(file);

    int start = count > DEFAULT_NUM_LINES ? count % DEFAULT_NUM_LINES : 0;
    int lines_to_print = count < DEFAULT_NUM_LINES ? count : DEFAULT_NUM_LINES;

    for (int i = 0; i < lines_to_print; i++) {
        printf("%s", buffer[(start + i) % DEFAULT_NUM_LINES]);
    }

    return 0;
}

