#include <stdio.h>
#include <utmpx.h>
#include <time.h>

void print_user_info(struct utmpx *ut) {
    struct tm *tm_info;
    char time_buffer[26];

    // 시간 정보를 가져와서 문자열로 변환
    tm_info = localtime(&ut->ut_tv.tv_sec);
    strftime(time_buffer, sizeof(time_buffer), "%m %d %H:%M", tm_info);

    // 사용자 정보 출력
    printf("%-16s %-12s %s\n", ut->ut_user, ut->ut_line, time_buffer);
}

int main() {
    struct utmpx *ut;

    // utmpx 파일 열기
    setutxent();
    printf("Username        Port         Login Time\n");
    while ((ut = getutxent()) != NULL) {
        // 사용자 레코드인지 확인
        if (ut->ut_type == USER_PROCESS) {
            print_user_info(ut);
        }
    }
    endutxent();

    return 0;
}
