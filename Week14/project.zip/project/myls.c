#include <stdio.h>
#include <dirent.h>

int main(int argc, char *argv[]) {
    DIR *d = opendir((argc > 1) ? argv[1] : ".");
    struct dirent *dir;

    if (!d) {
        perror("opendir");
        return 1;
    }

    while ((dir = readdir(d)))
        if (dir->d_name[0] != '.')
            printf("%s\n", dir->d_name);

    closedir(d);
    return 0;
}

