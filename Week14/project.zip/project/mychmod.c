#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "사용법: %s <파일이름> <권한>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *filename = argv[1];
    mode_t mode = strtol(argv[2], NULL, 8); // 8진수 권한 값을 정수로 변환

    if (chmod(filename, mode) == -1) {
        perror("chmod");
        exit(EXIT_FAILURE);
    }

    printf("파일 %s의 권한이 %o로 변경되었습니다.\n", filename, mode);
    return 0;
}

