#include <stdio.h>
#include <stdlib.h>
#include <sys/utsname.h>

int main() {
    struct utsname buffer;

    if (uname(&buffer) != 0) {
        perror("uname");
        exit(EXIT_FAILURE);
    }

    printf("System Name:    %s\n", buffer.sysname);
    printf("Node Name:      %s\n", buffer.nodename);
    printf("Release:        %s\n", buffer.release);
    printf("Version:        %s\n", buffer.version);
    printf("Machine:        %s\n", buffer.machine);

    return EXIT_SUCCESS;
}

