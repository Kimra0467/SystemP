#include <stdio.h>
#include <unistd.h>

int main() {
    char *username = getlogin(); // 현재 로그인한 사용자의 이름을 가져옴

    if (username) {
        printf("%s\n", username); // 사용자 이름을 출력
    } else {
        fprintf(stderr, "Failed to get username\n");
        return 1;
    }

    return 0;
}

