#include <stdio.h>
#include <stdlib.h>

#define DEFAULT_NUM_LINES 10

void print_head(FILE *file, int num_lines) {
    char buffer[256];
    int line_count = 0;

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        if (line_count >= num_lines) {
            break;
        }
        fputs(buffer, stdout);
        line_count++;
    }
}

int main(int argc, char *argv[]) {
    FILE *file;
    int num_lines = DEFAULT_NUM_LINES;

    if (argc < 2 || argc > 3) {
        fprintf(stderr, "Usage: %s [-n num_lines] <filename>\n", argv[0]);
        return 1;
    }

    if (argc == 3) {
        if (sscanf(argv[1], "-n%d", &num_lines) != 1) {
            fprintf(stderr, "Invalid number of lines: %s\n", argv[1]);
            return 1;
        }
        file = fopen(argv[2], "r");
    } else {
        file = fopen(argv[1], "r");
    }

    if (!file) {
        perror("Error opening file");
        return 1;
    }

    print_head(file, num_lines);

    fclose(file);
    return 0;
}

