#include <stdio.h>
#include <unistd.h>
#include <limits.h> // PATH_MAX를 사용하기 위해 필요

int main() {
    char cwd[PATH_MAX]; // 현재 작업 디렉토리를 저장할 버퍼

    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("%s\n", cwd); // 현재 작업 디렉토리를 출력
    } else {
        perror("getcwd() error"); // 오류 발생 시 에러 메시지 출력
        return 1;
    }

    return 0;
}

